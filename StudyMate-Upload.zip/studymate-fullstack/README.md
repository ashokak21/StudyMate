# StudyMate – Node.js server version

Same screens as the website, but data and uploaded files are saved on the server, so every device sees the same data.

## Run
1. Install Node.js 18 or newer.
2. In this folder run: `node server.js`
3. Open http://localhost:3000

No `npm install` is needed. Data is saved in `data/db.json` and uploaded files in `data/files/` (both ignored by Git).

## Demo accounts
| Role | Login | Password |
|---|---|---|
| Admin | `admin@college.edu` | `admin123` |
| Faculty | `meena@college.edu` | `faculty123` |
| Student | `arun@college.edu` or `RA2511000000001` | `student123` |

## What the server does
- Login by e-mail, register number or username; passwords hashed with scrypt
- 30-second lock after 5 wrong attempts; automatic logout after 30 minutes of inactivity
- Role checks on every request (students cannot upload, only admin manages users and subjects)
- File upload and download, up to 25 MB

## Settings (optional environment variables)
- `PORT` – port number (default 3000)
- `DATA_DIR` – folder for the data (default `./data`); point it to a persistent disk when hosting
- `IDLE_MINUTES` – inactivity limit (default 30)
